﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation;
using Hahn.ApplicatonProcess.December2020.Data;
using Hahn.ApplicatonProcess.December2020.Domain.Models;
using Hahn.ApplicatonProcess.December2020.Domain.Persistence;
using Hahn.ApplicatonProcess.December2020.Domain.Repository.Implementation;
using Hahn.ApplicatonProcess.December2020.Domain.Repository.Interface;
using Hahn.ApplicatonProcess.December2020.Web.Models;
using Hahn.ApplicatonProcess.December2020.Web.Validators;
using Microsoft.Extensions.DependencyInjection;

namespace Hahn.ApplicatonProcess.December2020.Web.Extensions
{
    public static class ApplicationServicesExtensions
    {
        public static IServiceCollection AddApplicationServices(this IServiceCollection services)
        {
            services.AddTransient<IValidator<ApplicantDto>, ApplicantValidator<ApplicantDto>>();

            services.AddScoped<IApplicantRepository, ApplicantRepository>();
            services.AddScoped<IRepository<Applicant>, ApplicantService>();

            return services;
        }
    }
}
