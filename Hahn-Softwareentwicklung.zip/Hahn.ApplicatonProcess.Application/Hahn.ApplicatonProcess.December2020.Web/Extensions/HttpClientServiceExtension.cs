﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Hahn.ApplicatonProcess.December2020.Domain.Validators;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using CountryValidator = Hahn.ApplicatonProcess.December2020.Web.Validators.CountryValidator;

namespace Hahn.ApplicatonProcess.December2020.Web.Extensions
{
    public static class HttpClientServiceExtension
    {
        private const string Url = "https://restcountries.eu/rest/v2/name/";    
        public static IServiceCollection HttpClientConfig(this IServiceCollection services)
        {
            services.AddHttpClient(nameof(CountryValidator), config =>
            {
                var uri = new Uri(Url);
                config.BaseAddress = uri;
                config.Timeout = new TimeSpan(0, 0, 15);
                var servicePoint = ServicePointManager.FindServicePoint(uri);
            });

            return services;
        }
    }
}
