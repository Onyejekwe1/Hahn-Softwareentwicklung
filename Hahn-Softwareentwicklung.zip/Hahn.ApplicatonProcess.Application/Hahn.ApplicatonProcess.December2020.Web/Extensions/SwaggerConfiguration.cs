﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Swashbuckle.AspNetCore.Filters;
using Swashbuckle.AspNetCore.Swagger;

namespace Hahn.ApplicatonProcess.December2020.Web.Extensions
{
    public static class SwaggerConfiguration
    {
        public static IServiceCollection AddSwaggerConfig(this IServiceCollection services)
        {
            services.AddSwaggerGen(setUpAction =>
            {
                setUpAction.SwaggerDoc("ApplicantApi", new Microsoft.OpenApi.Models.OpenApiInfo
                {
                    Title = "Applicants Api Dashboard",
                    Version = "v1"
                });
                setUpAction.ExampleFilters();

                var xmlCommentsFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                setUpAction.IncludeXmlComments(xmlCommentsFile);
                setUpAction.AddFluentValidationRules();
            });
            services.AddSwaggerExamplesFromAssemblies(Assembly.GetEntryAssembly());

            return services;
        }

        public static IApplicationBuilder CustomSwaggerAppConfig(this IApplicationBuilder app)
        {
            app.UseSwagger();

            app.UseSwaggerUI(setUpAction =>
            {
                setUpAction.SwaggerEndpoint("/swagger/ApplicantApi/swagger.json", "Applicant API");
                setUpAction.RoutePrefix = "";

            });

            return app;
        }
    }
}
