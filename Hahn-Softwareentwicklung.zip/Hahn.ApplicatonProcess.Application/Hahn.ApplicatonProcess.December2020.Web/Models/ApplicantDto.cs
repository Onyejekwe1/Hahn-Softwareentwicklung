﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Web.Models
{
    /// <summary>
    /// An applicant object
    /// </summary>
    public class ApplicantDto
    {
        /// <summary>
        /// The Id of an Applicant 
        /// </summary>
        public int Id { get; set; }


        /// <summary>
        /// The name of Applicant
        /// </summary>
        public string Name { get; set; }


        /// <summary>
        /// The Surname of an Applicant
        /// </summary>
        public string FamilyName { get; set; }


        /// <summary>
        /// The address of an Applicant
        /// </summary>
        public string Address { get; set; }


        /// <summary>
        /// The Country of Origin of an Applicant
        /// </summary>
        public string CountryOfOrigin { get; set; }


        /// <summary>
        /// The Email address of an Applicant
        /// </summary>
        public string EmailAddress { get; set; }


        /// <summary>
        /// The Age of an Applicant
        /// </summary>
        public int Age { get; set; }


        /// <summary>
        /// Employment status of an Applicant (Hired or Not)
        /// </summary>
        public bool Hired { get; set; }
    }
}
