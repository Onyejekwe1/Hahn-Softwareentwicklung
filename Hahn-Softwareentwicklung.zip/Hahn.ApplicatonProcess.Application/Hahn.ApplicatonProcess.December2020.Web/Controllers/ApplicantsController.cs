﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Hahn.ApplicatonProcess.December2020.Domain.Models;
using Hahn.ApplicatonProcess.December2020.Domain.Repository.Interface;
using Hahn.ApplicatonProcess.December2020.Domain.Response;
using Hahn.ApplicatonProcess.December2020.Web.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace Hahn.ApplicatonProcess.December2020.Web.Controllers
{
    [ApiController]
    [Route("api/applicants")]
    [Consumes("application/json")]
    [Produces("application/json")]

    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public class ApplicantsController : ControllerBase
    {
        private readonly ILogger<ApplicantsController> _logger;
        private readonly IMapper _mapper;
        private readonly IApplicantRepository _applicantRepository;

        public ApplicantsController(ILogger<ApplicantsController> logger, IMapper mapper, IApplicantRepository applicantRepository)
        {
            _logger = logger;
            _mapper = mapper;
            _applicantRepository = applicantRepository;
        }

        /// <summary>
        /// Get an Applicant by their id
        /// </summary>
        /// <param name="applicantId">Id of the applicant in question</param>
        /// <returns>An Applicant Object</returns>
        /// <remarks>The object returned can subsequently be used for an update</remarks>
        [ProducesResponseType(typeof(ApplicantDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [HttpGet("{applicantId}", Name = "GetApplicant")]
        public async Task<ActionResult<ApplicantDto>> GetApplicant(int applicantId)
        {
            var applicant = await _applicantRepository.GetApplicant(applicantId);

            return applicant != null ? Ok(_mapper.Map<ApplicantDto>(applicant)) : Problem("Applicant not found", statusCode: 404);
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<ActionResult<ApplicantDto>> CreateApplicant([FromBody] ApplicantDto dto)
        {
            var applicantObj = _mapper.Map<Applicant>(dto);

            var result = await _applicantRepository.CreateApplicant(applicantObj);

            return result != null ? Ok(_mapper.Map<ApplicantDto>(result)) : Problem("Error Occured", statusCode: 500);
        }


        /// <summary>
        /// Updates an applicant's record
        /// </summary>
        /// <param name="applicantId">Id of the applicant in question</param>
        /// <param name="dto"></param>
        [HttpPut("{applicantId}")]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public async Task<BaseResponse> CreateApplicant(int applicantId, ApplicantDto dto)
        {
            var applicant = await _applicantRepository.GetApplicant(applicantId);

            if (applicant == null) return BaseResponse.Failed();

            var applicantObj = _mapper.Map<Applicant>(dto);

            var result = await _applicantRepository.UpdateApplicant(applicantId, applicantObj);

            return result;

        }


        /// <summary>
        /// Delete an applicant's record
        /// </summary>
        /// <param name="applicantId">Id of the applicant in question</param>
        [HttpDelete("{applicantId}")]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public async Task<BaseResponse> DeleteApplicant(int applicantId)
        {
            var result = await _applicantRepository.DeleteApplicant(applicantId);

            return result;
        }
    }
}
