﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hahn.ApplicatonProcess.December2020.Domain.Models;
using Hahn.ApplicatonProcess.December2020.Domain.Response;

namespace Hahn.ApplicatonProcess.December2020.Domain.Repository.Interface
{
    public interface IApplicantRepository   
    {
        Task<Applicant> CreateApplicant(Applicant applicant);
        Task<BaseResponse> UpdateApplicant(int id, Applicant applicant);
        Task<BaseResponse> DeleteApplicant(int id);

        Task<Applicant> GetApplicant(int id);
    }
}
