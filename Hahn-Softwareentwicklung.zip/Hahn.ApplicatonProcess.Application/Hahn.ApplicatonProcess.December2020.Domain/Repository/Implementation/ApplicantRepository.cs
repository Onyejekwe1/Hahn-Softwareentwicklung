﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hahn.ApplicatonProcess.December2020.Domain.Models;
using Hahn.ApplicatonProcess.December2020.Domain.Persistence;
using Hahn.ApplicatonProcess.December2020.Domain.Repository.Interface;
using Hahn.ApplicatonProcess.December2020.Domain.Response;

namespace Hahn.ApplicatonProcess.December2020.Domain.Repository.Implementation
{
    public class ApplicantRepository : IApplicantRepository
    {
        private readonly IRepository<Applicant> _repository;

        public ApplicantRepository(IRepository<Applicant> repository)
        {
            _repository = repository;
        }

        public async Task<Applicant> CreateApplicant(Applicant applicant)
        {
            if (applicant is null)
            {
                throw new ArgumentNullException(nameof(applicant));
            }
            var result = await _repository.Create(applicant);
            return result;
        }

        public async Task<BaseResponse> UpdateApplicant(int id, Applicant applicant)
        {
            if (applicant is null)
            {
                return BaseResponse.BadRequestResponse("Applicant not found!");
            }

            var (result, _) = await _repository.Update(id, applicant);

            return result;
        }

        public async Task<BaseResponse> DeleteApplicant(int id)
        {
            var result =  await _repository.Delete(id);
            return result;
        }

        public async Task<Applicant> GetApplicant(int id)
        {
            var result = await _repository.GetById(id);
            return result;
        }
    }
}
