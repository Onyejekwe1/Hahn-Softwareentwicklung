﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain.Response
{
    public class BaseResponse
    {
        public bool Status { get; set; }
        public string Message { get; set; }
        public object Data { get; set; }    

        public BaseResponse(bool status)
        {
            this.Status = status;
        }

        public BaseResponse(bool status, string message)
        {
            this.Status = status;
            this.Message = message;
        }

        public BaseResponse(bool status, string message, object data)
        {
            this.Status = status;
            this.Message = message;
            this.Data = data;
        }

        public static BaseResponse Create(bool status)
        {
            return new BaseResponse(status);
        }

        public static BaseResponse Create(bool status, string message)
        {
            return new BaseResponse(status, message);
        }

        public static BaseResponse Create(bool status, string message, object data)
        {
            return new BaseResponse(status, message, data);
        }

        public static BaseResponse Ok(string message, object data)
        {
            return new BaseResponse(true, message, data);
        }

        public static BaseResponse Ok(object data)
        {
            return new BaseResponse(true, "Successful", data);
        }

        public static BaseResponse BadRequest(string message, object data)
        {
            return new BaseResponse(false, message, data);
        }

        public static BaseResponse BadRequestResponse(string message)
        {
            return new BaseResponse(false, message);
        }

        public static BaseResponse BadRequest(string message)
        {
            return BadRequest(message, null);
        }

        public static BaseResponse Failed()
        {
            return BadRequest("Request failed, please try again.", null);
        }
    }
}
