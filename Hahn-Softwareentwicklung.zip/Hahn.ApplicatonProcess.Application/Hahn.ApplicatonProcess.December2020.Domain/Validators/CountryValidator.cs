﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using FluentValidation.Results;
using FluentValidation.Validators;

namespace Hahn.ApplicatonProcess.December2020.Domain.Validators
{
    public class CountryValidator : PropertyValidator
    {
        private readonly HttpClient _httpClient;

        public CountryValidator(IHttpClientFactory httpClientFactory) : base($"Invalid Country {{PropertyName}}")
        {
            _httpClient = httpClientFactory.CreateClient(nameof(CountryValidator));
        }

        protected override bool IsValid(PropertyValidatorContext context)
        {
            var country = context.PropertyValue.ToString();

            if (!string.IsNullOrEmpty(country))
            {
                using var response = _httpClient.GetAsync($"{country}?fullText=true").GetAwaiter().GetResult();
                return response.IsSuccessStatusCode;
            }

            return false;
        }
    }
}
