﻿using System.Net.Http;
using FluentValidation;
using Hahn.ApplicatonProcess.December2020.Domain.Models;

namespace Hahn.ApplicatonProcess.December2020.Domain.Validators
{
    public class ApplicantValidator : AbstractValidator<Applicant>
    {
        public ApplicantValidator(IHttpClientFactory httpClientFactory)
        {
            RuleFor(x => x.Name)
                .NotEmpty()
                .MinimumLength(5);

            RuleFor(x => x.FamilyName)
                .NotEmpty()
                .MinimumLength(5);

            RuleFor(x => x.Age)
                .InclusiveBetween(20, 60);

            RuleFor(x => x.Address)
                .NotEmpty()
                .MinimumLength(10);

            RuleFor(x => x.EmailAddress)
                .NotEmpty()
                .EmailAddress();

            RuleFor(x => x.CountryOfOrigin)
                .NotEmpty()
                .SetValidator(new CountryValidator(httpClientFactory));
        }
    }
}
