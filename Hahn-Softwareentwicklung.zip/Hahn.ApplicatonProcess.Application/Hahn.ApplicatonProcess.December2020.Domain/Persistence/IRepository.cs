﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hahn.ApplicatonProcess.December2020.Domain.Response;

namespace Hahn.ApplicatonProcess.December2020.Domain.Persistence
{
    public interface IRepository<T> where T : new()
    {
        Task<T> Create(T item);
        Task<T> GetById(int id);
        Task<BaseResponse> Delete(int id);
        Task<(BaseResponse, int)> Update(int id, T item);   

    }
}
