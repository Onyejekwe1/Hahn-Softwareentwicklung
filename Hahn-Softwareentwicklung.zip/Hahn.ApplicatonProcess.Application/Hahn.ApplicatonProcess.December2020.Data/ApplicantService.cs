﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hahn.ApplicatonProcess.December2020.Domain.Models;
using Hahn.ApplicatonProcess.December2020.Domain.Persistence;
using Hahn.ApplicatonProcess.December2020.Domain.Response;
using Microsoft.EntityFrameworkCore;

namespace Hahn.ApplicatonProcess.December2020.Data
{
    public class ApplicantService : IRepository<Applicant>
    {
        private readonly ApplicationDbContext _dbContext;

        public ApplicantService(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<Applicant> Create(Applicant item)
        {
            if (await GetById(item.Id) != null)
            {
                return default;
            }
            var applicantEntity = await _dbContext.Applicants.AddAsync(item);
            await _dbContext.SaveChangesAsync();
            return applicantEntity.Entity;
        }

        public async Task<BaseResponse> Delete(int id)
        {
            var dbEntity = await GetById(id);
            if (dbEntity == null) return BaseResponse.Failed();


            _dbContext.Applicants.Remove(dbEntity);
            await _dbContext.SaveChangesAsync();
            return BaseResponse.Ok("Applicant Deleted Successfully!");
        }

        public Task<Applicant> GetById(int id)
        {
            return _dbContext.Applicants.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<(BaseResponse, int)> Update(int id, Applicant item)
        {
            var applicant = await GetById(id);
            if (applicant == null) return (BaseResponse.BadRequestResponse("Applicant not found!"), default);
            applicant.Name = item.Name;
            applicant.FamilyName = item.FamilyName;
            applicant.EmailAddress = item.EmailAddress;
            applicant.Address = item.Address;
            applicant.Age = item.Age;
            applicant.CountryOfOrigin = item.CountryOfOrigin;
            applicant.Hired = item.Hired;

            await _dbContext.SaveChangesAsync();

            return (BaseResponse.Ok("Successfully Updated!", applicant), applicant.Id);
        }
    }
}
