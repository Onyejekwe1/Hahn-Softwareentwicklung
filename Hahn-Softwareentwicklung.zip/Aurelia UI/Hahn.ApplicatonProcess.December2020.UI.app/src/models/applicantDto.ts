/**
 * An applicant
 */
export interface ApplicantDto { 
    /**
     * The id of applicant
     */
    id?: number;
    /**
     * The name of applicant
     */
    name?: string;
    /**
     * The surname of applicant
     */
    familyName?: string;
    /**
     * The address of applicant
     */
    address?: string;
    /**
     * The country of origin of applicant
     */
    countryOfOrigin?: string;
    /**
     * The email address of applicant
     */
    emailAddress?: string;
    /**
     * The age of applicant
     */
    age?: number;
    /**
     * The property specifying if the applicant is hired
     */
    hired?: boolean;
}
