export class Success{
  
}
